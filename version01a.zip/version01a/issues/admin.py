from django.contrib import admin
from .models import Issue, Update
admin.site.register(Issue)
admin.site.register(Update)
