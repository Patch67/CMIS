from django.apps import AppConfig


class OpencmisConfig(AppConfig):
    name = 'opencmis'
